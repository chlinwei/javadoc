CREATE PROCEDURE pro_testByIf(IN num INT, OUT str VARCHAR(20))
  BEGIN  
	IF num=1 then 
		set str='星期一';
	elseif num=2 then 
		set str='星期二'; 
	elseif num=3 then 
		set str='星期三';
	end if; 
end;
