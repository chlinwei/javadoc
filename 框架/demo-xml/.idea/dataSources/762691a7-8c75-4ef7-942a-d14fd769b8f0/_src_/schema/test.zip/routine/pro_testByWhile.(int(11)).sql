CREATE PROCEDURE pro_testByWhile(IN num INT, OUT score INT)
  BEGIN  
	declare i int default 1;  
	declare result int default 0;
	while i<=num do
		set result = result + i;
		set i = i + 1;
	end while;
	set score = result;
end;
