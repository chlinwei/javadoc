CREATE PROCEDURE pro_testByData(IN eid INT, OUT sname VARCHAR(20))
  BEGIN  
	
	
	select name into sname from employee;
end;
