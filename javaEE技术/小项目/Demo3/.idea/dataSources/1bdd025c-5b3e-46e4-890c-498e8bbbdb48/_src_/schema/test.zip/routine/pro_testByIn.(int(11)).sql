CREATE PROCEDURE pro_testByIn(IN eid INT)
  BEGIN
SELECT * FROM employee WHERE id=eid;
END;
