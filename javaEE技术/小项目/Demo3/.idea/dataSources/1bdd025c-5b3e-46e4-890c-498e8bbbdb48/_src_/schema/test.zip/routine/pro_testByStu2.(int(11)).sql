CREATE PROCEDURE pro_testByStu2(IN sid INT, OUT sname VARCHAR(20))
  BEGIN
    SELECT NAME INTO sname FROM student WHERE  id=sid;
END;
