CREATE PROCEDURE pro_testByStu(IN sid INT)
  BEGIN
    SELECT * FROM student WHERE id=sid;
  END;
